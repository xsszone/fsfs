import DefizoneLanding from "@/components/defizone-landing";

export default function Home() {
  return (
      <DefizoneLanding/>
  );
}
