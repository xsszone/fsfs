import Image from "next/image";
import logoIcon from "@/public/logo_defi.svg";
import {Badge} from "@/components/ui/badge";
import {Button} from "@/components/ui/button";
import Link from "next/link";
import {Send} from "lucide-react";
import {DefizoneDonate} from "@/components/defizone-card-donate";


export default function Page() {
    return (
        <div className="flex flex-col min-h-screen">
            <header
                className="sticky top-0 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
                <div className="container flex h-14">
                    <div className="flex items-center space-x-4">
                        <Image
                            priority
                            src={logoIcon}
                            height={64}
                            width={64}
                            alt="Defi Logo"
                        />
                        <span className="font-semibold text-xl absolute left-0 pl-8">Defizone <Badge variant="outline">Beta</Badge></span>
                        <div className="absolute items-center end-5">
                            <Button asChild variant="outline">
                                <Link href="https://t.me/kdefizone" target="_blank" rel="noopener noreferrer">
                                    <Send/>Telegram
                                </Link>
                            </Button>
                        </div>
                    </div>
                    {/*<div className="flex-auto"/>*/}
                </div>
            </header>
            <main className="flex-1">
                <section id="features" className="w-full py-12 md:py-24 lg:py-32 bg-gray-100 dark:bg-gray-800 flex items-center justify-center w-full">
                    <DefizoneDonate/>
                </section>
            </main>
            <footer className="border-t">
                <div
                    className="container flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6">
                    <p className="text-xs text-muted-foreground">© 2024 Defizone. All rights reserved.</p>
                    <nav className="sm:ml-auto flex gap-4 sm:gap-6">

                    </nav>
                </div>
            </footer>
        </div>
    )
}