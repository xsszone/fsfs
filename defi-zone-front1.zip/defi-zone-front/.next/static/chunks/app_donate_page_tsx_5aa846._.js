(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_donate_page_tsx_5aa846._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_donate_page_tsx_5aa846._.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_13e51f._.js",
    "static/chunks/app_donate_page_tsx_d748e6._.js"
  ],
  "source": "dynamic"
});
