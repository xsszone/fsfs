(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_5aa846._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_5aa846._.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_e95187._.js",
    "static/chunks/app_page_tsx_9fdd4f._.js"
  ],
  "source": "dynamic"
});
