import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {Code, Gamepad2, Shield} from 'lucide-react'
import Link from "next/link"
export default function DefizoneLanding() {
    return (
        <div className="flex flex-col min-h-screen">
            <header
                className="sticky top-0 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
                <div className="container flex h-14 ">
                    <div className="flex items-center space-x-4 pl-3">
                        <Shield className="h-6 w-6"/>
                        <span className="font-bold text-xl">Defizone</span>
                    </div>
                    <div className="flex-auto"/>
                </div>
            </header>
            <main className="flex-1">
                <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48">
                    <div className="container px-4 md:px-6">
                        <div className="flex flex-col items-center space-y-4 text-center">
                            <div className="space-y-2">
                                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                                    Добро пожаловать в Defizone
                                </h1>
                                <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                                    Разработка передового программного обеспечения для улучшения игрового опыта
                                </p>
                            </div>
                            <div className="space-x-4">
                                {/*<Button asChild>*/}
                                {/*    <Link href="#features">Узнать больше</Link>*/}
                                {/*</Button>*/}
                                <Button asChild variant="outline">
                                    <Link href="https://t.me/kdefizone" target="_blank" rel="noopener noreferrer">
                                        Присоединиться к Telegram
                                    </Link>
                                </Button>
                            </div>
                        </div>
                    </div>
                </section>
                <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-100 dark:bg-gray-800">
                    <div className="container px-4 md:px-6">
                        <div className="flex flex-col items-center space-y-4 text-center">
                            <div className="space-y-2">
                                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">О нашем
                                    проекте</h2>
                                <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                                    Defizone специализируется на разработке программного обеспечения для улучшения
                                    игрового опыта.
                                    Наши инструменты помогают игрокам раскрыть свой полный потенциал в виртуальных
                                    мирах.
                                </p>
                            </div>
                            <div className="w-full max-w-sm space-y-2">
                                <p className="text-sm text-red-500 dark:text-red-400">
                                    Предупреждение: Использование стороннего ПО может нарушать правила некоторых игр.
                                    Пожалуйста, используйте наши продукты ответственно и на свой страх и риск.
                                </p>
                            </div>
                        </div>
                    </div>
                </section>
                <section id="features" className="w-full py-12 md:py-24 lg:py-32 bg-gray-100 dark:bg-gray-800">
                    <div className="container px-4 md:px-6">
                        <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-center mb-12">Наши
                            преимущества</h2>
                        <div className="grid gap-6 lg:grid-cols-3 lg:gap-12">
                            <Card>
                                <CardHeader>
                                    <Gamepad2 className="w-8 h-8 mb-2"/>
                                    <CardTitle>Улучшенный геймплей</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <CardDescription>Наше ПО обеспечивает непревзойденное преимущество в игре, улучшая
                                        ваш игровой опыт.</CardDescription>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader>
                                    <Shield className="w-8 h-8 mb-2"/>
                                    <CardTitle>Безопасность</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <CardDescription>Мы уделяем особое внимание безопасности наших продуктов, чтобы
                                        защитить ваши аккаунты.</CardDescription>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader>
                                    <Code className="w-8 h-8 mb-2"/>
                                    <CardTitle>Постоянные обновления</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <CardDescription>Наша команда постоянно работает над улучшением и обновлением нашего
                                        ПО.</CardDescription>
                                </CardContent>
                            </Card>
                        </div>
                    </div>
                </section>
            </main>
            <footer className="border-t">
                <div
                    className="container flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6">
                    <p className="text-xs text-muted-foreground">© 2024 Defizone. All rights reserved.</p>
                    <nav className="sm:ml-auto flex gap-4 sm:gap-6">
                        <Link className="text-xs hover:underline underline-offset-4" href="#">
                            Terms of Service
                        </Link>
                        <Link className="text-xs hover:underline underline-offset-4" href="#">
                            Privacy
                        </Link>
                    </nav>
                </div>
            </footer>
        </div>
    )
}